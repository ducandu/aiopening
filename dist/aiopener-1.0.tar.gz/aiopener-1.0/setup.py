"""
 -------------------------------------------------------------------------
 shine - 
 setup
 
 !!TODO: add file description here!! 
  
 created: 2017/06/04 in PyCharm
 (c) 2017 Sven - ducandu GmbH
 -------------------------------------------------------------------------
"""

from setuptools import setup

setup(name='aiopener', version='1.0', description='AI (but even opener)', url='http://github.com/sven1977/aiopener', author='Sven Mika',
      author_email='sven.mika@ducandu.com', license='MIT', packages=['aiopener'], zip_safe=False)