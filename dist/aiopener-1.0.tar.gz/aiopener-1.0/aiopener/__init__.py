"""
 ---------------------------------------------------------------------------------
 shine - [s]erver [h]osted [i]ntelligent [n]eural-net [e]nvironment :)
 ---------------------------------------------------------------------------------

 by Code Sourcerer
 (c) 2017 ducandu GmbH
"""

# import all packs in all directories (one level down)
# from pyrate.auxiliary import *

# import all modules in this directory
from aiopener.aiopener import *

# global pack vars
_VERSION = 1  # 00.00.01 = 1
